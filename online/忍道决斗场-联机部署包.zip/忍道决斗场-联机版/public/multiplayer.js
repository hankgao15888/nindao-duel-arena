/* Remote PvP: clients send controls, while the included server simulates both teams. */
(() => {
  'use strict';
  const enabled=window.ARENA_RUNTIME?.multiplayer===true,$=id=>document.getElementById(id),auth=window.ArenaAuth,roster=new Map((window.NINJAS||[]).map(n=>[n.id,n]));
  let hooks={},socket=null,connecting=null,room=null,adapter=null,retryTimer,pingTimer,heartbeatTimer,attempt=0,wantsLobby=false,stopping=false,lastPing=null;
  const roomKey='arena-online-room';let resumeHint=null;try{resumeHint=JSON.parse(sessionStorage.getItem(roomKey)||'null');}catch{}
  function rememberRoom(){try{if(room)sessionStorage.setItem(roomKey,JSON.stringify({code:room.code,userId:auth.user?.id}));else sessionStorage.removeItem(roomKey);}catch{}}
  const inert=new Map(),root=document.createElement('div');root.id='arenaMultiplayer';root.hidden=true;
  root.innerHTML=`<section class="online-panel" role="dialog" aria-modal="true" aria-labelledby="onlineTitle" tabindex="-1">
    <button id="onlineClose" type="button" class="online-close" aria-label="关闭联机窗口">✕</button>
    <p class="online-eyebrow">ONLINE DUEL · 好友切磋</p><h2 id="onlineTitle">远程联机对决</h2><p class="online-intro">分享房间码，双方准备后开始 3V3 对战。</p>
    <div class="online-connection"><i id="onlineDot"></i><span id="onlineConnection">尚未连接</span><b id="onlinePing">— ms</b></div>
    <div id="onlineEntrance"><button id="onlineCreate" type="button" class="online-primary">创建房间</button><div class="online-divider">或加入好友房间</div><label for="onlineCodeInput">房间码</label><div class="online-join"><input id="onlineCodeInput" maxlength="6" autocomplete="off" autocapitalize="characters" placeholder="输入 6 位房间码"><button id="onlineJoin" type="button">加入</button></div></div>
    <div id="onlineRoom" hidden><div class="online-code"><span>房间码 <strong id="onlineCode"></strong></span><button id="onlineCopy" type="button">复制</button></div><div id="onlineSeats" class="online-seats"></div><p id="onlineCountdown" class="online-countdown"></p><button id="onlineReady" type="button" class="online-primary">准备对战</button><div class="online-room-actions"><button id="onlineAdjust" type="button">调整出战阵容</button><button id="onlineLeave" type="button">离开房间</button></div></div>
    <div id="onlineStatus" class="online-message" role="status" aria-live="polite"></div><p class="online-note">对战期间关闭窗口、切换页面或打开聊天不会暂停计时。<br>断线后有 15 秒重连时间；主动离开视为认输。</p>
  </section>`;
  document.body.append(root);
  const tag=document.createElement('div');tag.id='onlineMatchTag';tag.className='online-match-tag';tag.hidden=true;$('hud').append(tag);
  const entry=$('onlineEntry');if(entry)entry.hidden=!enabled;
  const status=(message,error=false)=>{$('onlineStatus').textContent=message;$('onlineStatus').classList.toggle('error',error);};
  function connection(message,connected=false){$('onlineConnection').textContent=message;$('onlineDot').classList.toggle('connected',connected);if(adapter){tag.textContent=(room?'房间 '+room.code+' · ':'')+message+(lastPing!==null?' · '+lastPing+' ms':'');tag.classList.toggle('disconnected',!connected);}}
  function send(message){if(socket?.readyState===WebSocket.OPEN){socket.send(JSON.stringify(message));return true;}return false;}
  function teamNames(team){return (team||[]).map(id=>{const n=roster.get(id);return n?n.name+(n.variant?'「'+n.variant+'」':''):id;}).join(' · ');}
  function renderRoom(){
    $('onlineEntrance').hidden=!!room;$('onlineRoom').hidden=!room;if(!room)return;$('onlineCode').textContent=room.code;
    $('onlineSeats').replaceChildren();
    for(const side of ['player','enemy']){const player=room.players[side==='player'?0:1],card=document.createElement('article');card.className='online-seat'+(side===room.you?' own':'');const title=document.createElement('h3'),team=document.createElement('p'),state=document.createElement('small');title.textContent=player?(side===room.you?'你 · ':'')+player.username:'等待好友加入';team.textContent=player?teamNames(player.team):'将上方房间码发送给好友';state.textContent=player?(!player.connected?'重连中':player.ready?'已准备':'未准备'):'等待中';state.className=player?.ready?'ready':'';card.append(title,team,state);$('onlineSeats').append(card);}
    const mine=room.players[room.you==='player'?0:1];$('onlineReady').textContent=mine?.ready?'取消准备':'准备对战';$('onlineReady').disabled=['countdown','playing'].includes(room.phase)||socket?.readyState!==WebSocket.OPEN;
    $('onlineAdjust').disabled=['countdown','playing'].includes(room.phase);$('onlineCountdown').textContent=room.phase==='countdown'?room.remaining+' 秒后开始':room.phase==='playing'?'对战进行中':room.phase==='finished'?'双方再次准备即可再战':'选择好阵容后点击准备';
  }
  function close(){if(root.hidden)return;root.hidden=true;for(const [region,value]of inert)region.inert=value;inert.clear();window.dispatchEvent(new CustomEvent('arena-online-close'));(!$('selection').hidden?entry:$('arena'))?.focus();}
  function open(){
    if(!enabled)return;if(!auth?.user){wantsLobby=true;auth?.open('登录后即可创建联机房间、邀请好友对决。');return;}
    if(root.hidden){window.dispatchEvent(new CustomEvent('arena-before-online-open'));for(const region of document.querySelectorAll('.game-shell,#arenaChat')){inert.set(region,region.inert);region.inert=true;}(document.fullscreenElement||document.body).append(root);root.hidden=false;window.dispatchEvent(new CustomEvent('arena-online-open'));}
    renderRoom();(room?$('onlineReady'):$('onlineCreate')).focus();connect().catch(()=>{});
  }
  function viewState(value,side){
    const state=value;
    if(side==='enemy'){
      const flip=v=>{if(Array.isArray(v))return v.map(flip);if(v&&typeof v==='object'){const out={};for(const [key,item]of Object.entries(v))out[key]=flip(item);return out;}return v==='player'?'enemy':v==='enemy'?'player':v;};
      const transformed=flip(state);[transformed.player,transformed.enemy]=[transformed.enemy,transformed.player];[transformed.teams.player,transformed.teams.enemy]=[transformed.teams.enemy,transformed.teams.player];[transformed.indices.player,transformed.indices.enemy]=[transformed.indices.enemy,transformed.indices.player];
      transformed.combo=state.enemyCombo||0;if(transformed.status==='ended')transformed.banner=transformed.result?.winner==='player'?'决斗胜利':transformed.result?.winner==='enemy'?'决斗失败':'平局';
      return hydrate(transformed);
    }
    return hydrate(state);
  }
  function hydrate(state){
    const visit=value=>{if(!value||typeof value!=='object')return;for(const [key,item]of Object.entries(value)){if(key==='profile')value.profile=roster.get(item.id)||item;else visit(item);}};visit(state);return state;
  }
  class RemoteEngine{
    constructor(message){this.isRemote=true;this.mode='online';this.match=message.match;this.sequence=0;this.input={x:0,y:0};this.held=new Set();this.scroll='gate';this.samples=[];this.frame=-1;this.state=viewState(message.state,room.you);this.accept(message);}
    accept(message){
      if(message.frame<this.frame)return;this.frame=message.frame;const state=viewState(message.state,room.you);this.samples.push({at:performance.now(),state});this.samples=this.samples.slice(-5);this.state=state;
      for(const event of message.events||[])hooks.onEvent?.(event);
    }
    setInput(input={}){const x=Math.max(-1,Math.min(1,Number(input.x)||0)),y=Math.max(-1,Math.min(1,Number(input.y)||0));if(Math.abs(x-this.input.x)>.001||Math.abs(y-this.input.y)>.001){this.input={x,y};this.flush();}}
    setButtonHeld(key,value){if(!['j','u','i','q','e'].includes(key)||this.held.has(key)===!!value)return;if(value)this.held.add(key);else this.held.delete(key);this.flush();}
    setXiayinScroll(value){this.scroll=value==='forest'?'forest':'gate';this.flush();}
    action(key){if(this.state.status!=='playing')return false;this.flush([key]);return true;}
    flush(actions=[]){send({type:'control',seq:++this.sequence,x:this.input.x,y:this.input.y,held:[...this.held],actions,scroll:this.scroll});}
    pause(){return this;}
    update(){
      const newest=this.samples.at(-1);if(!newest)return;const now=performance.now(),target=now-50;
      let previous=this.samples[0],next=newest;for(let i=1;i<this.samples.length;i++)if(this.samples[i].at>=target){previous=this.samples[i-1];next=this.samples[i];break;}
      this.state=JSON.parse(JSON.stringify(newest.state));hydrate(this.state);
      const factor=Math.max(0,Math.min(1,(target-previous.at)/Math.max(1,next.at-previous.at)));
      for(const side of ['player','enemy']){const a=previous.state[side],b=next.state[side],f=this.state[side];if(a?.uid===b?.uid&&f.uid===b.uid){for(const key of ['x','y','air'])f[key]=a[key]+(b[key]-a[key])*factor;for(const key of ['shenju','xiayin','obito'])if(a[key]&&b[key]&&f[key])f[key].height=a[key].height+(b[key].height-a[key].height)*factor;}}
      if(socket?.readyState!==WebSocket.OPEN&&this.state.status!=='ended'){this.state.status='paused';this.state.banner='连接中断，正在重连';this.state.bannerTime=1;}
    }
  }
  function disconnectedMatch(){if(adapter&&adapter.state.status!=='ended'){adapter.state.status='ended';adapter.state.result={winner:'draw',reason:'connection_lost'};adapter.samples=[];hooks.onEvent?.({type:'end'});}}
  function connect(){
    if(connecting)return connecting;if(socket?.readyState===WebSocket.OPEN)return Promise.resolve();if(!auth?.user)return Promise.reject(Error('请先登录。'));
    stopping=false;connection(attempt?'连接中断，正在重连':'正在连接');
    connecting=new Promise((resolve,reject)=>{
      const url=new URL('/api/duel/socket',location.origin);url.protocol=url.protocol==='https:'?'wss:':'ws:';const ws=new WebSocket(url);socket=ws;
      const timeout=setTimeout(()=>{if(connecting)ws.close();},8000);
      ws.onopen=()=>ws.send(JSON.stringify({type:'auth',token:auth.token}));
      ws.onmessage=event=>{
        let message;try{message=JSON.parse(event.data);}catch{return;}
        if(message.type==='welcome'){
          if(message.protocol!==1||message.roster.length!==roster.size||message.roster.some(id=>!roster.has(id))){status('游戏版本已更新，请刷新页面后重新连接。',true);stopping=true;ws.close();return;}
          clearTimeout(timeout);connecting=null;attempt=0;connection('已连接',true);status('');if((room||resumeHint)&&!message.reconnected){room=null;resumeHint=null;rememberRoom();disconnectedMatch();renderRoom();status('原房间已经结束，可以重新创建或加入。',true);}
          clearInterval(pingTimer);pingTimer=setInterval(()=>send({type:'ping',sent:performance.now()}),2000);clearInterval(heartbeatTimer);heartbeatTimer=setInterval(()=>{if(adapter&&room?.phase==='playing')adapter.flush();},150);resolve();return;
        }
        if(message.type==='pong'){lastPing=Math.max(0,Math.round(performance.now()-message.sent));$('onlinePing').textContent=lastPing+' ms';connection(lastPing>250?'延迟偏高':'已连接',true);return;}
        if(message.type==='room'){room=message;rememberRoom();renderRoom();if(resumeHint&&message.phase!=='playing'){resumeHint=null;open();}if(message.phase==='countdown')status('双方已准备，正在进入决斗场。');if(message.phase==='playing'&&message.players.some(player=>!player?.connected))connection('等待对手重连');return;}
        if(message.type==='snapshot'){
          if(!room)return;if(!adapter||adapter.match!==message.match){adapter=new RemoteEngine(message);tag.hidden=false;connection('已连接',true);close();hooks.onMatch?.(adapter);}else adapter.accept(message);return;
        }
        if(message.type==='closed'){room=null;resumeHint=null;rememberRoom();renderRoom();status(message.message);if(adapter?.state.status!=='ended'){adapter=null;tag.hidden=true;hooks.onLeave?.();}return;}
        if(message.type==='error')status(message.message,true);
      };
      ws.onerror=()=>status('无法连接联机服务，请检查网络或服务器地址。',true);
      ws.onclose=event=>{
        clearTimeout(timeout);clearInterval(pingTimer);clearInterval(heartbeatTimer);connecting=null;reject(Error('连接已断开'));connection('连接已断开');
        if(stopping||!auth?.user)return;
        if(event.code===4001){status('登录已过期，请重新登录。',true);auth.fetch('/api/chat/auth/me').catch(()=>{});return;}
        if(event.code===4002){stopping=true;status('此房间已在另一个页面打开。',true);disconnectedMatch();return;}
        if(attempt++<8){clearTimeout(retryTimer);retryTimer=setTimeout(()=>connect().catch(()=>{}),Math.min(3000,250*2**attempt));}else{disconnectedMatch();status('重连失败，请重新进入房间。',true);}
      };
    });return connecting;
  }
  function leave(){if(room)send({type:'leave'});room=null;resumeHint=null;rememberRoom();adapter=null;tag.hidden=true;renderRoom();}
  if(entry)entry.onclick=open;$('onlineClose').onclick=close;$('onlineAdjust').onclick=close;
  $('onlineCreate').onclick=async()=>{try{await connect();send({type:'create',team:hooks.getTeam?.()});}catch{status('连接未完成，请稍后重试。',true);}};
  $('onlineJoin').onclick=async()=>{const code=$('onlineCodeInput').value.trim().toUpperCase();if(!/^[A-HJ-NP-Z2-9]{6}$/.test(code)){status('请输入正确的 6 位房间码。',true);return;}try{await connect();send({type:'join',code,team:hooks.getTeam?.()});}catch{status('连接未完成，请稍后重试。',true);}};
  $('onlineCodeInput').addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();$('onlineJoin').click();}});
  $('onlineReady').onclick=()=>{const mine=room?.players[room.you==='player'?0:1];send({type:'ready',ready:!mine?.ready,team:hooks.getTeam?.()});};
  $('onlineLeave').onclick=()=>{leave();hooks.onLeave?.();};
  $('onlineCopy').onclick=async()=>{try{await navigator.clipboard.writeText(room.code);status('房间码已复制，发送给好友即可。');}catch{status('房间码：'+room.code+'，请手动复制。');}};
  root.addEventListener('keydown',event=>{if(root.hidden)return;event.stopPropagation();if(event.key==='Escape'){event.preventDefault();close();return;}if(event.key==='Tab'){const fields=[...root.querySelectorAll('button,input')].filter(el=>!el.disabled&&el.getClientRects().length),first=fields[0],last=fields.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}});
  root.addEventListener('keyup',event=>{if(!root.hidden)event.stopPropagation();});
  document.addEventListener('fullscreenchange',()=>{if(!root.hidden)(document.fullscreenElement||document.body).append(root);});
  addEventListener('arena-before-auth-open',close);
  addEventListener('arena-auth-close',event=>{if(wantsLobby&&event.detail?.authenticated)queueMicrotask(open);wantsLobby=false;});
  addEventListener('arena-auth-change',()=>{if(!auth?.user){leave();stopping=true;clearTimeout(retryTimer);socket?.close();close();hooks.onLeave?.();}});
  addEventListener('pagehide',()=>{stopping=true;socket?.close();});
  addEventListener('pageshow',()=>{if(enabled&&room&&auth?.user)connect().catch(()=>{});});
  window.ArenaMultiplayer={setup(value){hooks=value;auth?.ready.then(()=>{if(enabled&&resumeHint?.userId===auth.user?.id&&auth.user)connect().catch(()=>{});});},open,close,leave,get active(){return !!room;}};
})();
