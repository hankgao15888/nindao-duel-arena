import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {loadCombat,snapshot} from '../lib/combat.mjs';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const {OnlineCombat,roster}=loadCombat(path.join(root,'public'));
const other=side=>side==='player'?'enemy':'player';
const make=(id='naruto-kcm',enemy=id)=>new OnlineCombat({roster,team:[id],enemy:[enemy]}).start();
const tick=(e,seconds)=>{for(let t=0;t<seconds-1e-8;t+=1/120)e.update(Math.min(1/120,seconds-t));};
function hit(e,side,props={}){return e._hit(e.state[other(side)],e.state[side],{damage:60,lift:0,stun:.3,knockback:0,...props});}
function denied(e,side,label){const f=e.state[side],before=JSON.stringify([f.x,f.y,f.chakra,f.cooldowns.space,f.invuln]);assert.equal(e.sideAction(side,'space'),false,label);assert.equal(JSON.stringify([f.x,f.y,f.chakra,f.cooldowns.space,f.invuln]),before,'denial must not spend resources or teleport');}

test('all 24 ninjas, both seats: neutral denial, real damage, exact shared Y and behind both facings',()=>{
  for(const n of roster)for(const side of ['player','enemy'])for(const facing of [-1,1]){
    const e=make(n.id),f=e.state[side],a=e.state[other(side)];a.x=640;a.y=facing===1?400:590;a.facing=facing;f.y=505;
    denied(e,side,n.id+' neutral');assert.equal(hit(e,side),true);assert.ok(f.hp<f.maxHP);assert.equal(e.sideAction(side,'space'),true,n.id+' damaged');
    assert.equal(f.y,a.y);assert.equal(f.x,a.x-facing*160);assert.ok((f.x-a.x)*facing<0);assert.equal(f.chakra,1);assert.equal(f.cooldowns.space,15);assert.equal(f._substitutionHit,null);
    assert.equal(f.air,0);assert.equal(f.stun,0);assert.equal(f.invulnKind,'substitute');
    f.cooldowns.space=0;denied(e,side,'cannot reuse the same damage');
  }
});

test('whiffs, invulnerability, guards, phase and artificial control do not grant substitution',()=>{
  for(const side of ['player','enemy']){
    const miss=make();miss.state[side].x=150;miss.state[other(side)].x=1100;miss.sideAction(other(side),'j');tick(miss,.5);assert.equal(miss.state[side].hp,3000);denied(miss,side,'whiff');
    const dodge=make();dodge.state[side].invuln=1;assert.equal(hit(dodge,side),false);denied(dodge,side,'invulnerable');
    for(const id of ['madara-shenju','hashirama-xiayin','sasuke-xiayin']){
      const e=make(id),f=e.state[side];
      if(f.shenju)f.shenju.block=1;
      else if(f.xiayin)f.xiayin.guard=1;
      else {f.sasukeXiayin.guard=1;f.facing=e.state[other(side)].x>=f.x?1:-1;}
      assert.equal(hit(e,side),true,'guard resolves collision');assert.equal(f.hp,3000);denied(e,side,id+' guard');
    }
    const phase=make('obito-war');phase.state[side].obito.phase=1;assert.equal(hit(phase,side),false);denied(phase,side,'phase');
    for(const key of ['stun','air','knockdown','captured','inKamui','obRoot','sxGrab']){const e=make();e.state[side][key]=key==='stun'||key==='air'||key==='knockdown'?1:{owner:other(side),ownerUid:e.state[other(side)].uid};denied(e,side,key+' without damage');}
  }
});

test('a completed damage reaction, getup, reset, death or round change invalidates old damage',()=>{
  for(const side of ['player','enemy']){
    const e=make();hit(e,side);tick(e,.4);denied(e,side,'neutral after stagger');assert.equal(e.state[side]._substitutionHit,null);
    const air=make();hit(air,side,{lift:250});tick(air,1.3);denied(air,side,'land and recover');
    const reset=make();hit(reset,side);reset._resetReaction(reset.state[side]);reset.state[side].stun=1;denied(reset,side,'reset removes receipt');
    const round=make();hit(round,side);round._defeat(round.state[other(side)],'test');assert.equal(round.state[side]._substitutionHit,null);denied(round,side,'round over');
    const dead=make();hit(dead,side,{damage:100000});denied(dead,side,'dead');
  }
});

test('cooldown and chakra requirements still apply to genuinely damaged fighters',()=>{
  for(const side of ['player','enemy']){
    const e=make();hit(e,side);e.state[side].chakra=0;denied(e,side,'no chakra');e.state[side].chakra=2;e.state[side].cooldowns.space=1;denied(e,side,'cooldown');e.state[side].cooldowns.space=0;assert.equal(e.sideAction(side,'space'),true);
  }
});

test('armored hits and burn ticks while neutral cannot be used as an active escape',()=>{
  const armor=make(),f=armor.state.player;f.armorKind='adamant';f.armorTime=f.actionTime=1;f.action='skill';hit(armor,'player');assert.ok(f.hp<3000);denied(armor,'player','armor with no reaction');
  const dot=make('sasuke-xiayin');hit(dot,'player',{sxDot:true});assert.ok(dot.state.player.hp<3000);denied(dot,'player','burn with no reaction');
});

test('wall substitutions remain visibly behind and do not snap onto the enemy on the next frame',()=>{
  for(const side of ['player','enemy'])for(const [x,facing] of [[25,1],[50,1],[100,1],[1180,-1],[1230,-1],[1255,-1]]){
    const e=make(),f=e.state[side],a=e.state[other(side)];a.x=x;a._substituteEdge=x<100||x>1180;a.y=455;a.facing=facing;hit(e,side);assert.equal(e.sideAction(side,'space'),true);const landing=f.x;
    assert.ok((landing-a.x)*facing<0);assert.ok(landing>0&&landing<1280);tick(e,.4);assert.equal(f.x,landing);assert.equal(f.y,a.y);
    e.setSideInput(side,0,1);tick(e,.1);assert.equal(f.x,landing,'Y movement preserves rear margin');e.setSideInput(side,facing,0);tick(e,1);assert.ok(f.x>=100&&f.x<=1180,'can move back into regular stage');
  }
});

test('damaging bell, Kamui, wood root and Sasuke grabs can be escaped without pulling the landing back',()=>{
  for(const side of ['player','enemy'])for(const kind of ['bell','kamui','root','sasuke']){
    const attacker=kind==='bell'?'hashirama-xiayin':kind==='sasuke'?'sasuke-xiayin':'obito-war';
    const e=side==='player'?make('naruto-kcm',attacker):make(attacker,'naruto-kcm'),f=e.state[side],a=e.state[other(side)];a.x=640;a.y=490;a.facing=1;
    if(kind==='bell'){const b=e._xyBell(a,500,540,true);e._hit(a,f,{damage:60,grab:true,captureBell:b});assert.ok(f.captured);}
    else if(kind==='kamui'){hit(e,side);e._obPocket(a,f,2);assert.ok(f.inKamui);}
    else if(kind==='root'){e._hit(a,f,{damage:60,root:2});assert.ok(f.obRoot);}
    else {e._hit(a,f,{damage:60,grab:true,sxCapture:2});assert.ok(f.sxGrab);}
    assert.ok(f.hp<3000);assert.equal(e.sideAction(side,'space'),true,kind+' escape');const x=f.x,y=f.y;assert.equal(y,a.y);assert.equal(x,a.x-a.facing*160);assert.ok(!f.captured&&!f.inKamui&&!f.obRoot&&!f.sxGrab);tick(e,.1);assert.equal(f.x,x);assert.equal(f.y,y);
  }
});

test('real basic attacks create serializable eligibility for both seats and never allow pre-hit use',()=>{
  for(const side of ['player','enemy']){
    const e=make(),f=e.state[side],a=e.state[other(side)];e.state.player.x=530;e.state.enemy.x=650;
    denied(e,side,'pre-hit');e.sideAction(other(side),'j');for(let i=0;i<60&&f.hp===3000;i++)e.update(1/120);assert.ok(f.hp<3000,'real collision damage');
    const s=snapshot(e);assert.equal(s[side]._substitutionHit.attackerUid,a.uid);assert.equal(s[side]._substitutionHit.attackerSide,a.side);assert.equal(e.sideAction(side,'space'),true);assert.equal(f.y,a.y);
  }
});
