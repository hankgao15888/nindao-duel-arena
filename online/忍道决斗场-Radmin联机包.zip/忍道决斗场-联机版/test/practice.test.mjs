import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const publicRoot=path.join(path.dirname(fileURLToPath(import.meta.url)),'../public');
const window={},context=vm.createContext({window,console,Math});
for(const name of ['roster','engine','shenju','xiayin','obito','sasuke-xiayin','practice','controls'])vm.runInContext(fs.readFileSync(path.join(publicRoot,name+'.js'),'utf8'),context,{filename:name});
const make=(id='naruto-kcm',extra={})=>new window.ArenaEngine({roster:window.NINJAS,team:['naruto-kcm'],enemy:[id],mode:'training',...extra}).start();
const tick=(e,s)=>{for(let t=0;t<s-1e-8;t+=1/120)e.update(Math.min(1/120,s-t));};
test('manual practice casts work for all ninjas without an autonomous opponent',()=>{
 const idle=make(),x=idle.state.enemy.x;tick(idle,2);assert.equal(idle.state.enemy.x,x);assert.equal(idle.state.player.hp,3000);
 for(const n of window.NINJAS)for(const key of ['j','u','i','o','l','h']){const e=make(n.id);assert.equal(e.practiceAction(key),true,n.id+' '+key);tick(e,4);for(const f of [e.state.player,e.state.enemy])assert.ok(Number.isFinite(f.x+f.y+f.hp+f.air));}
 const duel=make('naruto-kcm',{mode:'duel'});assert.equal(duel.practiceAction('u'),false);assert.equal(duel.setPracticeOpponent('obito-war'),false);assert.equal(duel._onlineInputs,undefined);
});
test('changing opponent clears pending attacks, releases holds, preserves player profile and respects access',()=>{
 const e=make('hashirama-xiayin');e.setPracticeHeld('u',true);e.practiceAction('u');tick(e,.4);assert.ok(e.state.enemy.xiayin.guard>0);
 const playerId=e.state.player.id;assert.equal(e.setPracticeOpponent('sasuke-xiayin'),true);assert.equal(e.state.enemy.id,'sasuke-xiayin');assert.equal(e.state.enemy.hp,3000);assert.equal(e.state.enemy.chakra,4);assert.equal(e.state.player.id,playerId);assert.equal(e._onlineButtons.enemy.u,false);assert.equal(e.state.entities.length,0);
 const gated=make('naruto-kcm',{canPracticeOpponent:id=>id!=='obito-war'});assert.equal(gated.setPracticeOpponent('obito-war'),false);assert.equal(gated.setPracticeOpponent('unknown'),false);
});
test('held ultimate, pause, substitution and opponent recovery retain combat rules',()=>{
 const e=make('sasuke-xiayin');e.setPracticeHeld('o',true);e.practiceAction('o');tick(e,.45);assert.equal(e.state.enemy.sasukeXiayin.move.fx,'ultMountain');e.releasePractice();assert.equal(e._onlineButtons.enemy.o,false);
 e.pause(true);assert.equal(e.practiceAction('j'),false);e.pause(false);e._defeat(e.state.enemy,'test');tick(e,1.2);assert.equal(e.state.enemy.dead,false);assert.equal(e.state.enemy.hp,3000);assert.equal(e.state.enemy.chakra,4);
 const sub=make();assert.equal(sub.practiceAction('space'),false);sub._hit(sub.state.player,sub.state.enemy,{damage:60,lift:200});assert.equal(sub.practiceAction('space'),true);assert.equal(sub.state.enemy.y,sub.state.player.y);
});
test('new opponent shortcuts preserve existing custom keys and resolve conflicts',()=>{
 const K=window.ArenaKeybindings;const initial=new K();const old=Object.fromEntries(Object.entries(initial.bindings).filter(([id])=>!id.startsWith('enemy_')));old.j='Digit1';let saved=JSON.stringify(old);
 const storage={getItem:()=>saved,setItem:(key,value)=>saved=value};let k=new K(storage);assert.equal(k.resolve('Digit1'),'j');assert.notEqual(k.bindings.enemy_j,'Digit1');assert.equal(new Set(Object.values(k.bindings)).size,22);
 k.bind('enemy_u','KeyJ');k=new K(storage);assert.equal(k.resolve('KeyJ'),'enemy_u');k.reset();assert.equal(k.resolve('Digit2'),'enemy_u');
});
test('practice reset replenishes the entire team, revives defeated ninjas and restores opening positions',()=>{
 const team=['madara-shenju','hashirama-xiayin','sasuke-xiayin'];const e=make('obito-war',{team});
 e.setPracticeOpponent('sasuke-xiayin');
 for(const side of ['player','enemy'])for(const f of e.state.teams[side]){f.hp=5;f.chakra=0;f.dead=true;f.x=600;f.y=420;f.air=100;f.stun=3;f.cooldowns.u=8;f.cooldowns.space=12;if(f.shenju)f.shenju.energy=0;if(f.sasukeXiayin)f.sasukeXiayin.energy=0;}
 e.state.indices.player=1;e.state.player=e.state.teams.player[1];e.state.entities.push({life:5});e.state.effects.push({life:5});e._switches.enemy=.01;e.setPracticeHeld('o',true);e.setButtonHeld('u',true);e.setInput({x:1,y:-1});e._practiceQueue=e._queuedAttack=true;e.state.status='ended';
 assert.equal(e.resetPractice(),true);assert.equal(e.state.status,'playing');assert.equal(e.state.indices.player,0);assert.equal(e.state.player.id,team[0]);assert.equal(e.state.enemy.id,'sasuke-xiayin');
 for(const side of ['player','enemy'])for(const f of e.state.teams[side]){assert.equal(f.hp,f.maxHP);assert.equal(f.chakra,f.maxChakra||4);assert.equal(f.dead,false);assert.equal(f.x,side==='player'?330:950);assert.equal(f.y,505);assert.equal(f.air,0);assert.equal(f.stun,0);assert.ok(Object.values(f.cooldowns).every(x=>x===0));if(f.shenju)assert.equal(f.shenju.energy,100);if(f.sasukeXiayin)assert.equal(f.sasukeXiayin.energy,2);}
 assert.equal(e.state.entities.length,0);assert.equal(e.state.effects.length,0);assert.equal(Object.keys(e._switches).length,0);assert.equal(Object.keys(e._onlineButtons.enemy).length,0);assert.equal(e.input.x,0);assert.equal(e.input.y,0);assert.equal(e._practiceQueue,false);assert.equal(e._queuedAttack,false);
 tick(e,.5);assert.equal(e.state.player.hp,3000);assert.equal(e.state.enemy.hp,3000);assert.equal(e.state.player.x,330);assert.equal(e.state.enemy.x,950);
});
test('reset cancels real delayed skill events and cannot alter duel state',()=>{
 const e=make('sasuke-xiayin');e.setPracticeHeld('o',true);e.practiceAction('o');tick(e,.45);assert.equal(e.state.enemy.sasukeXiayin.move.fx,'ultMountain');e.resetPractice();tick(e,4.5);assert.equal(e.state.player.hp,3000);assert.equal(e.state.enemy.hp,3000);assert.equal(e.state.enemy.sasukeXiayin.move,null);
 const duel=make('naruto-kcm',{mode:'duel'}),before=JSON.stringify(duel.state);assert.equal(duel.resetPractice(),false);assert.equal(JSON.stringify(duel.state),before);
});
