import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import WebSocket from 'ws';
import {loadCombat,snapshot} from '../lib/combat.mjs';
import {Rooms} from '../lib/rooms.mjs';
import {createArenaServer} from '../server.mjs';
import {storage} from '../lib/storage.mjs';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url))),combat=loadCombat(path.join(root,'public'));
const team=['naruto-kcm','sasuke-susanoo','kakashi-war'];
function temporary(){return fs.mkdtempSync(path.join(os.tmpdir(),'arena-online-test-'));}
function cleanup(directory){const resolved=path.resolve(directory);assert.ok(resolved.startsWith(path.resolve(os.tmpdir())+path.sep)&&path.basename(resolved).startsWith('arena-online-test-'));fs.rmSync(resolved,{recursive:true,force:true});}

test('concurrent account/chat batches commit independently and roll back failed batches',async()=>{
  const directory=temporary(),data=storage(directory,path.join(root,'migrations'));
  try{
    data.sql.exec('CREATE TABLE batch_test(id INTEGER PRIMARY KEY,value TEXT NOT NULL)');
    const statement=(id,value)=>data.DB.prepare('INSERT INTO batch_test VALUES (?,?)').bind(id,value);
    await Promise.all([data.DB.batch([statement(1,'a'),statement(2,'a')]),data.DB.batch([statement(3,'b'),statement(4,'b')])]);
    assert.equal(data.sql.prepare('SELECT COUNT(*) AS count FROM batch_test').get().count,4);
    await assert.rejects(data.DB.batch([statement(5,'c'),statement(1,'duplicate')]));
    assert.equal(data.sql.prepare('SELECT COUNT(*) AS count FROM batch_test').get().count,4);
  }finally{data.close();cleanup(directory);}
});
test('both seats move independently; the second seat has no CPU',()=>{
  const e=new combat.OnlineCombat({roster:combat.roster,team,enemy:team});e.start();const initial=e.state.enemy.x;
  for(let i=0;i<60;i++)e.update(1/60);assert.equal(e.state.enemy.x,initial);
  e.setSideInput('enemy',-1,-1);e.setSideInput('player',1,1);for(let i=0;i<30;i++)e.update(1/60);
  assert.ok(e.state.enemy.x<initial);assert.ok(e.state.enemy.y<505);assert.ok(e.state.player.x>330);assert.ok(e.state.player.y>505);
});
test('every ninja can use attacks and both skills from both seats, with serializable snapshots',()=>{
  let casts=0;
  for(const ninja of combat.roster)for(const side of ['player','enemy'])for(const key of ['j','u','i']){
    const e=new combat.OnlineCombat({roster:combat.roster,team:[ninja.id],enemy:[ninja.id]});e.start();e.state.player.x=520;e.state.enemy.x=660;e.setSideInput(side,side==='player'?1:-1,.7);e.setSideHeld(side,key,true);const ok=e.sideAction(side,key);assert.equal(ok,true,`${ninja.id} ${side} ${key}`);casts++;
    for(let frame=0;frame<150;frame++){if(frame===15)e.setSideHeld(side,key,false);e.update(1/60);if(frame%10===0){const s=snapshot(e);assert.ok(Number.isFinite(s.player.hp)&&Number.isFinite(s.enemy.hp));assert.ok(!JSON.stringify(s).includes('"fn"'));}}
  }
  assert.equal(casts,combat.roster.length*6);
});
test('Obito held subskill and Xiayin guard work for the second human seat',()=>{
  const e=new combat.OnlineCombat({roster:combat.roster,team:['naruto-kcm'],enemy:['obito-war']});e.start();e.setSideInput('enemy',-1,.8);e.sideAction('enemy','i');for(let i=0;i<15;i++)e.update(1/60);e.setSideHeld('enemy','q',true);assert.equal(e.sideAction('enemy','q'),true);for(let i=0;i<12;i++)e.update(1/60);assert.equal(e.state.enemy.obito.phaseMove,true);
  const xy=new combat.OnlineCombat({roster:combat.roster,team:['naruto-kcm'],enemy:['hashirama-xiayin']});xy.start();xy.setSideHeld('enemy','u',true);xy.sideAction('enemy','u');for(let i=0;i<35;i++)xy.update(1/60);assert.ok(xy.state.enemy.xiayin.guard>0);xy.setSideHeld('enemy','u',false);xy.update(1/60);assert.equal(xy.state.enemy.xiayin.guard,0);
});
function client(id){const value={user:{id,username:id},messages:[],room:null,side:null};value.socket={readyState:1,bufferedAmount:0,send(bytes){value.messages.push(JSON.parse(bytes));},close(){}};return value;}

test('both players can ready again after a finished match with fresh health and cooldowns',()=>{
  let now=100000;const rooms=new Rooms({...combat,now:()=>now,countdownMs:100});const a=client('rematch_a'),b=client('rematch_b');const room=rooms.create(a,team);rooms.join(b,room.code,team);
  rooms.ready(a,true,team);rooms.ready(b,true,team);now+=101;rooms.tick();const firstMatch=room.match;
  room.engine.state.player.hp=400;room.engine.state.enemy.cooldowns.u=8;rooms.finish(room,'enemy','forfeit');
  rooms.ready(a,true,team);assert.equal(room.phase,'finished');rooms.ready(b,true,team);now+=101;rooms.tick();
  assert.equal(room.phase,'playing');assert.notEqual(room.match,firstMatch);assert.equal(room.engine.state.player.hp,3000);assert.equal(room.engine.state.enemy.cooldowns.u,0);
});
test('room validation, two-player readiness, stale input, reconnection and timeout forfeit',()=>{
  let now=100000;const rooms=new Rooms({...combat,now:()=>now,countdownMs:100,graceMs:500});const a=client('alice'),b=client('bob'),c=client('third');
  assert.throws(()=>rooms.create(a,['bad','bad','bad']));const room=rooms.create(a,team);assert.equal(room.code.length,6);assert.throws(()=>rooms.create(a,team));rooms.join(b,room.code,team);assert.throws(()=>rooms.join(c,room.code,team));
  rooms.ready(a,true,team);assert.equal(room.phase,'waiting');rooms.ready(b,true,team);assert.equal(room.phase,'countdown');now+=101;rooms.tick();assert.equal(room.phase,'playing');
  const initial=room.engine.state.enemy.x;rooms.input(b,{seq:1,x:-1,y:0,held:[],actions:[]});for(let i=0;i<10;i++){now+=17;rooms.tick();}assert.ok(room.engine.state.enemy.x<initial);
  rooms.input(b,{seq:1,x:1,y:0,held:[],actions:[]});assert.equal(room.engine._onlineInputs.enemy.x,-1,'old sequence ignored');
  now+=600;rooms.tick();assert.equal(room.engine._onlineInputs.enemy.x,0,'stale input released');rooms.disconnect(b);assert.equal(room.engine.state.status,'paused');const clock=room.engine.state.elapsed;now+=200;rooms.tick();assert.equal(room.engine.state.elapsed,clock);
  const back=client('bob');assert.equal(rooms.reconnect(back),true);assert.equal(room.engine.state.status,'playing');rooms.disconnect(back);now+=501;rooms.tick();assert.equal(room.phase,'finished');assert.equal(room.engine.state.result.winner,'player');assert.equal(room.engine.state.result.reason,'disconnect');
});
async function peer(base,token){
  const ws=new WebSocket(base.replace(/^http/,'ws')+'/api/duel/socket',{headers:{Origin:base}}),messages=[],waiters=[];
  ws.on('message',bytes=>{const m=JSON.parse(bytes);messages.push(m);for(const waiter of [...waiters])if(waiter.predicate(m)){waiters.splice(waiters.indexOf(waiter),1);clearTimeout(waiter.timer);waiter.resolve(m);}});
  const wait=(predicate,timeout=7000)=>{const previous=messages.find(predicate);if(previous)return Promise.resolve(previous);return new Promise((resolve,reject)=>{const value={predicate,resolve,timer:setTimeout(()=>{waiters.splice(waiters.indexOf(value),1);reject(Error('Timed out waiting for WebSocket event'));},timeout)};waiters.push(value);});};
  await new Promise((resolve,reject)=>{ws.once('open',resolve);ws.once('error',reject);});ws.send(JSON.stringify({type:'auth',token}));await wait(m=>m.type==='welcome');return {ws,messages,wait,send(value){ws.send(JSON.stringify(value));}};
}
test('real HTTP and two WebSocket clients: login, room, synchronized damage, auth denial and logout forfeit',async()=>{
  const directory=temporary(),app=createArenaServer({dataDirectory:directory,countdownMs:50,graceMs:300});let a,b;
  try{
    const address=await app.listen(0),base='http://127.0.0.1:'+address.port;
    const request=(endpoint,options={})=>fetch(base+endpoint,{...options,headers:{Origin:base,...options.headers}});
    for(const route of ['/api/chat/messages','/api/chat/images/1'])assert.equal((await request(route)).status,401);
    assert.equal((await request('/runtime-config.js')).status,200);assert.equal((await request('/lib/arena-auth.mjs')).status,404);assert.equal((await request('/api/chat/messages',{headers:{Origin:'https://evil.invalid'}})).status,403);
    async function register(username){const r=await request('/api/chat/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password:'OnlyLocalTestPass!2026'})});assert.equal(r.status,201);return r.json();}
    const alice=await register('network_alice'),bob=await register('network_bob');a=await peer(base,alice.token);b=await peer(base,bob.token);
    a.send({type:'create',team});const created=await a.wait(m=>m.type==='room');b.send({type:'join',code:created.code,team});await b.wait(m=>m.type==='room');a.send({type:'ready',ready:true,team});b.send({type:'ready',ready:true,team});
    const first=await a.wait(m=>m.type==='snapshot'),second=await b.wait(m=>m.type==='snapshot');assert.equal(first.match,second.match);assert.equal(first.state.enemy.uid,second.state.enemy.uid);
    let sequence=0,fighting=false;const control=setInterval(()=>{a.send({type:'control',seq:++sequence,x:fighting?0:1,y:0,held:[],actions:fighting&&sequence%3===0?['j']:[]});},70);
    try{await a.wait(m=>m.type==='snapshot'&&m.state.player.x>770,7000);fighting=true;const hitA=await a.wait(m=>m.type==='snapshot'&&m.state.enemy.hp<3000,7000),hitB=await b.wait(m=>m.type==='snapshot'&&m.state.enemy.hp<3000,7000);assert.ok(hitA.state.enemy.hp<3000);assert.ok(hitB.state.enemy.hp<3000);}finally{clearInterval(control);}
    // Client-reported health cannot alter the authoritative state.
    const before=app.rooms.rooms.get(created.code).engine.state.enemy.hp;a.send({type:'control',seq:++sequence,x:0,y:0,held:[],actions:[],hp:1,winner:'player'});await a.wait(m=>m.type==='snapshot'&&m.frame>first.frame+10);assert.notEqual(app.rooms.rooms.get(created.code).engine.state.enemy.hp,1);
    assert.equal((await request('/api/chat/auth/logout',{method:'POST',headers:{Authorization:'Bearer '+bob.token}})).status,200);const ended=await a.wait(m=>m.type==='snapshot'&&m.state.status==='ended');assert.equal(ended.state.result.winner,'player');assert.equal((await request('/api/chat/messages',{headers:{Authorization:'Bearer '+bob.token}})).status,401);
  }finally{a?.ws.terminate();b?.ws.terminate();await app.close();cleanup(directory);}
});

test('Sasuke branches and held ultimate work symmetrically for both human seats',()=>{
  for(const side of ['player','enemy'])for(const [action,fx] of [['uj','fireSword'],['uo','fireGuard'],['ij','thunderSword'],['io','rise']]){
    const e=new combat.OnlineCombat({roster:combat.roster,team:['sasuke-xiayin'],enemy:['sasuke-xiayin']}).start();
    e.state.player.x=400;e.state.enemy.x=1000;e.setSideInput(side,side==='player'?1:-1,-1);
    assert.equal(e.sideAction(side,action),true);assert.equal(e.state[side].sasukeXiayin.move.fx,fx);assert.equal(e.state[side].sasukeXiayin.energy,1);
    const json=snapshot(e);assert.equal(json[side].sasukeXiayin.events,undefined);assert.ok(!JSON.stringify(json).includes('fn'));
  }
  for(const side of ['player','enemy']){
    const e=new combat.OnlineCombat({roster:combat.roster,team:['sasuke-xiayin'],enemy:['sasuke-xiayin']}).start();e.state[side].chakra=4;e.setSideHeld(side,'o',true);e.sideAction(side,'o');
    for(let i=0;i<26;i++)e.update(1/60);assert.equal(e.state[side].sasukeXiayin.move.fx,'ultMountain');assert.equal(e.state[side].chakra,0);
    e.release(side);assert.equal(e._onlineButtons[side].o,false);
  }
});
test('rooms accept Sasuke swipe inputs and held O without expanding arbitrary actions',()=>{
  let now=100000;const rooms=new Rooms({...combat,now:()=>now,countdownMs:100});const a=client('sx_a'),b=client('sx_b'),squad=['sasuke-xiayin','naruto-kcm','obito-war'];const room=rooms.create(a,squad);rooms.join(b,room.code,squad);rooms.ready(a,true,squad);rooms.ready(b,true,squad);now+=101;rooms.tick();
  rooms.input(b,{seq:1,x:-1,y:0,held:['o'],actions:['io']});assert.equal(room.engine.state.enemy.sasukeXiayin.move.fx,'rise');assert.equal(room.engine._onlineButtons.enemy.o,true);
  assert.throws(()=>rooms.input(a,{seq:1,x:0,y:0,held:[],actions:['inject']}));
});
