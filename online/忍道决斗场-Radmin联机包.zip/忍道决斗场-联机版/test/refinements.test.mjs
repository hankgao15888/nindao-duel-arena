import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {loadCombat,snapshot} from '../lib/combat.mjs';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url))),{OnlineCombat,roster}=loadCombat(path.join(root,'public'));
const tick=(e,time)=>{for(let n=0;n<time*120;n++)e.update(1/120);};
test('every human seat retains joystick facing through neutral and attacks for all ninjas',()=>{
  for(const n of roster)for(const side of ['player','enemy']){
    const e=new OnlineCombat({roster,team:[n.id],enemy:[n.id]}).start(),f=e.state[side],dir=side==='player'?-1:1;
    e.setSideInput(side,dir,0);tick(e,.03);assert.equal(f.facing,dir,n.id+' '+side+' turn');e.setSideInput(side,0,0);tick(e,.03);assert.equal(f.facing,dir,n.id+' '+side+' neutral');assert.equal(e.sideAction(side,'j'),true);assert.equal(f.facing,dir,n.id+' '+side+' attack');
  }
});
test('both human seats can steer all enhanced Sasuke basic stages across Y',()=>{
  for(const side of ['player','enemy'])for(let stage=1;stage<=7;stage++){
    const e=new OnlineCombat({roster,team:['sasuke-xiayin'],enemy:['sasuke-xiayin']}).start(),f=e.state[side];f.x=640;f.y=530;f.sasukeXiayin.enhanced=10;f.sasukeXiayin.basicGrab=true;f.attackIndex=stage-1;f._lastBasic=0;e.setSideInput(side,0,-1);e.sideAction(side,'j');tick(e,.3);assert.ok(f.y<520,side+' '+stage+'A Y');assert.ok(Math.abs(f.x-640)<1,side+' pure Y preserves X');assert.ok(JSON.stringify(snapshot(e)).length>0);
  }
});
test('both human seats buffer a basic after skill recovery and can escape air holds',()=>{
  for(const side of ['player','enemy']){
    const e=new OnlineCombat({roster,team:['sasuke-xiayin'],enemy:['sasuke-xiayin']}).start(),f=e.state[side],target=e.state[side==='player'?'enemy':'player'];f.x=side==='player'?500:650;target.x=side==='player'?650:500;e.sideAction(side,'u');tick(e,.3);assert.equal(e.sideAction(side,'j'),true);tick(e,.78);assert.equal(f.sasukeXiayin.move?.fx,'basic');assert.ok(target.air>0);assert.equal(e.sideAction(target.side,'space'),true);assert.equal(target._airHold,null);assert.equal(target.air,0);
  }
});
