// The included server replaces this file with same-origin online configuration.
window.ARENA_RUNTIME=window.ARENA_RUNTIME||{apiBase:location.origin,multiplayer:false,protocol:1};
// LAN HTTP previews may lack randomUUID; use the browser's cryptographic RNG.
if(!crypto.randomUUID)crypto.randomUUID=()=>{const bytes=crypto.getRandomValues(new Uint8Array(16));bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;const value=[...bytes].map(v=>v.toString(16).padStart(2,'0')).join('');return value.slice(0,8)+'-'+value.slice(8,12)+'-'+value.slice(12,16)+'-'+value.slice(16,20)+'-'+value.slice(20);};
