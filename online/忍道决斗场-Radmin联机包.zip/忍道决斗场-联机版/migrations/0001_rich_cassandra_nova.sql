CREATE TABLE `site_presence` (
	`id` text PRIMARY KEY NOT NULL,
	`visitor_hash` text NOT NULL,
	`last_seen` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `site_presence_seen` ON `site_presence` (`last_seen`);--> statement-breakpoint
CREATE INDEX `site_presence_visitor` ON `site_presence` (`visitor_hash`);