CREATE TABLE `chat_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `chat_messages` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`author_id` text NOT NULL,
	`client_id` text NOT NULL,
	`nickname` text NOT NULL,
	`body` text NOT NULL,
	`image_key` text,
	`created_at` integer NOT NULL,
	`hidden` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `chat_messages_time` ON `chat_messages` (`created_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `chat_messages_retry` ON `chat_messages` (`author_id`,`client_id`);--> statement-breakpoint
CREATE INDEX `chat_messages_image` ON `chat_messages` (`image_key`);--> statement-breakpoint
CREATE TABLE `chat_reports` (
	`message_id` integer NOT NULL,
	`reporter` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `chat_reports_once` ON `chat_reports` (`message_id`,`reporter`);--> statement-breakpoint
CREATE TABLE `chat_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`token_hash` text NOT NULL,
	`expires_at` integer NOT NULL,
	`last_sent` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `chat_sessions_token_hash_unique` ON `chat_sessions` (`token_hash`);