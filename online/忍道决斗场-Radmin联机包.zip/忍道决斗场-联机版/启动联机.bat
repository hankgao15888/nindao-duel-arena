@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "ARENA_NODE=node"
if exist "C:\Program Files\nodejs\node.exe" set "ARENA_NODE=C:\Program Files\nodejs\node.exe"
echo 忍道决斗场 - 联机版
echo 请保持本窗口开启，然后在浏览器打开 http://127.0.0.1:3000
echo 需要 Node.js 24 LTS。首次使用请自行注册账号。
echo.
"%ARENA_NODE%" --env-file-if-exists=.env server.mjs
echo.
echo 服务已停止。若提示找不到 node，请先安装 Node.js 24 LTS。
pause
