@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "ARENA_NODE=node"
if exist "C:\Program Files\nodejs\node.exe" set "ARENA_NODE=C:\Program Files\nodejs\node.exe"
echo 忍道决斗场 - Radmin VPN 好友联机
"%ARENA_NODE%" radmin-start.mjs
echo.
echo 联机服务已停止。若启动失败，请查看上方提示。
pause
