import os from 'node:os';
import net from 'node:net';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';

const root=path.dirname(fileURLToPath(import.meta.url));
const interfaces=Object.entries(os.networkInterfaces()).flatMap(([name,values])=>(values||[]).filter(value=>value.family==='IPv4'&&!value.internal).map(value=>({name,address:value.address})));
const requested=process.env.RADMIN_IP?.trim();
const candidates=interfaces.filter(value=>requested?value.address===requested:/radmin|famatech/i.test(value.name));
if(Number(process.versions.node.split('.')[0])!==24){console.error('请使用 Node.js 24 LTS。');process.exit(1);}
if(requested&&net.isIP(requested)!==4){console.error('RADMIN_IP 必须是本机的有效 IPv4 地址。');process.exit(1);}
if(candidates.length!==1){console.error(candidates.length?'发现多个 VPN 地址，请设置 RADMIN_IP 后重试。':'没有找到 Radmin VPN 的 IPv4 地址。请先打开 Radmin VPN，加入或创建网络，再运行本脚本。');process.exit(1);}
const address=candidates[0].address,port=Number(process.env.PORT||3000);
if(!Number.isInteger(port)||port<1024||port>65535){console.error('PORT 必须在 1024—65535 之间。');process.exit(1);}
const origin=`http://${address}:${port}`;
console.log(`Radmin VPN 地址：${address}`);
console.log(`好友进入网址：${origin}/?online=1`);
if(process.argv.includes('--check'))process.exit(0);
console.log('请保持 Radmin VPN 和本窗口开启。好友须先加入同一个 Radmin 网络。');
console.log('仅监听选中的 VPN 地址；本程序不会修改防火墙或路由器。');
const child=spawn(process.execPath,['--env-file-if-exists=.env','server.mjs'],{cwd:root,env:{...process.env,HOST:address,PORT:String(port),PUBLIC_ORIGIN:origin,TRUST_PROXY:'0'},stdio:'inherit',windowsHide:true});
child.on('error',error=>{console.error('启动失败：'+error.message);process.exitCode=1;});
child.on('exit',code=>{process.exitCode=code??1;});
