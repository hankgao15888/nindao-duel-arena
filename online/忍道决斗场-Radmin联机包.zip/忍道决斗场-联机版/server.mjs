import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {WebSocketServer} from 'ws';
import {storage} from './lib/storage.mjs';
import {loadCombat} from './lib/combat.mjs';
import {Rooms,RoomError} from './lib/rooms.mjs';
import {handleChat} from './lib/arena-chat.mjs';
import {accountSession} from './lib/arena-auth.mjs';
const ROOT=path.dirname(fileURLToPath(import.meta.url)),PUBLIC=path.join(ROOT,'public');
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.svg':'image/svg+xml','.ico':'image/x-icon'};
export function createArenaServer(options={}){
  const data=storage(options.dataDirectory||path.join(ROOT,'data'),path.join(ROOT,'migrations'));
  const combat=loadCombat(PUBLIC),rooms=new Rooms({...combat,countdownMs:options.countdownMs??3000,graceMs:options.graceMs??15000,maxRooms:options.maxRooms??20});
  const clients=new Set(),operations=new Map();let stopped=false;
  const publicOrigin=options.publicOrigin?new URL(options.publicOrigin).origin:null;
  const originFor=request=>publicOrigin||new URL('http://'+request.headers.host).origin;
  const validOrigin=request=>request.headers.origin===originFor(request);
  const ipFor=request=>options.trustProxy?(request.headers['x-forwarded-for']?.split(',')[0].trim()||request.socket.remoteAddress):request.socket.remoteAddress;
  const json=(response,body,status=200)=>{response.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});response.end(JSON.stringify(body));};
  function body(request){return new Promise((resolve,reject)=>{let size=0,parts=[],settled=false;request.on('data',chunk=>{if(settled)return;size+=chunk.length;if(size>540672){settled=true;parts=[];reject(Object.assign(Error('请求内容过大。'),{status:413}));return;}parts.push(chunk);});request.on('end',()=>{if(!settled)resolve(Buffer.concat(parts));});request.on('error',reject);});}
  const server=http.createServer(async(request,response)=>{
    try{
      const origin=originFor(request),url=new URL(request.url,origin),wsOrigin=origin.replace(/^http/,'ws');
      response.setHeader('X-Content-Type-Options','nosniff');response.setHeader('Referrer-Policy','same-origin');response.setHeader('X-Frame-Options','SAMEORIGIN');
      response.setHeader('Content-Security-Policy',`default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; connect-src 'self' ${wsOrigin}; object-src 'none'; base-uri 'self'; frame-ancestors 'self'; form-action 'self'`);
      if(url.pathname==='/healthz'){json(response,{ok:true,version:'1.0.0',onlineRooms:rooms.rooms.size});return;}
      if(url.pathname==='/runtime-config.js'){
        response.writeHead(200,{'Content-Type':MIME['.js'],'Cache-Control':'no-store'});response.end('window.ARENA_RUNTIME={apiBase:"",multiplayer:true,protocol:1};\n'+fs.readFileSync(path.join(PUBLIC,'runtime-config.js'),'utf8'));return;
      }
      if(url.pathname.startsWith('/api/chat/')){
        if(request.headers.origin&&!validOrigin(request)){json(response,{error:'此来源无法使用账号或聊天服务。'},403);return;}
        if(request.headers.origin){response.setHeader('Access-Control-Allow-Origin',request.headers.origin);response.setHeader('Vary','Origin');}
        // Same-origin requests were checked above; the portable API needs no Cloudflare origin allowlist.
        const headers=new Headers();for(const [name,value]of Object.entries(request.headers))if(!['origin','host','connection','content-length'].includes(name)&&value)headers.set(name,Array.isArray(value)?value.join(','):value);
        headers.set('CF-Connecting-IP',ipFor(request)||'local');
        const bytes=['GET','HEAD','OPTIONS'].includes(request.method)?undefined:await body(request);
        const result=await handleChat(new Request(url,{method:request.method,headers,body:bytes?.length?bytes:undefined}),data);
        if(url.pathname==='/api/chat/auth/logout'&&result.ok){const token=headers.get('Authorization')?.replace(/^Bearer /,'');for(const client of clients)if(token&&client.token===token){if(client.room)try{rooms.leave(client);}catch{}client.socket.close(4001,'Signed out');}}
        result.headers.forEach((value,name)=>{if(!['access-control-allow-origin','vary'].includes(name))response.setHeader(name,value);});response.statusCode=result.status;response.end(Buffer.from(await result.arrayBuffer()));return;
      }
      if(request.method!=='GET'&&request.method!=='HEAD'){json(response,{error:'不支持此请求。'},405);return;}
      const pathname=decodeURIComponent(url.pathname),target=path.resolve(PUBLIC,'.'+(pathname==='/'?'/index.html':pathname));
      if(!target.startsWith(PUBLIC+path.sep)||!MIME[path.extname(target).toLowerCase()]){json(response,{error:'没有找到文件。'},404);return;}
      let stat;try{stat=fs.statSync(target);}catch{json(response,{error:'没有找到文件。'},404);return;}
      if(!stat.isFile()){json(response,{error:'没有找到文件。'},404);return;}
      response.writeHead(200,{'Content-Type':MIME[path.extname(target).toLowerCase()],'Content-Length':stat.size,'Cache-Control':'no-cache'});if(request.method==='HEAD')response.end();else fs.createReadStream(target).pipe(response);
    }catch(error){if(!response.headersSent)json(response,{error:error.status?error.message:'服务暂时不可用，请重试。'},error.status||503);else response.end();if(!error.status)console.error('HTTP request failed:',error.message);}
  });
  server.requestTimeout=15000;server.headersTimeout=10000;
  const sockets=new WebSocketServer({noServer:true,maxPayload:4096,perMessageDeflate:false});
  server.on('upgrade',(request,socket,head)=>{
    try{const pathname=new URL(request.url,originFor(request)).pathname;
      if(pathname!=='/api/duel/socket'||!validOrigin(request)||clients.size>=100){socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n');socket.destroy();return;}
      sockets.handleUpgrade(request,socket,head,ws=>sockets.emit('connection',ws,request));
    }catch{socket.destroy();}
  });
  async function validate(client){const value=await accountSession(new Request('http://arena.local/api/chat/auth/me',{headers:{Authorization:'Bearer '+client.token}}),data.DB);if(value.id!==client.user.id)throw Error('Invalid account');return value;}
  sockets.on('connection',(socket,request)=>{
    const client={socket,user:null,token:null,room:null,side:null,alive:true,lastCheck:Date.now(),authenticating:false,window:Date.now(),count:0,errors:0};clients.add(client);
    const timeout=setTimeout(()=>{if(!client.user)socket.close(4001,'Sign in required');},5000);timeout.unref();
    socket.on('pong',()=>{client.alive=true;});
    socket.on('close',()=>{clearTimeout(timeout);clients.delete(client);rooms.disconnect(client);});socket.on('error',()=>{});
    socket.on('message',async bytes=>{
      try{
        const now=Date.now();if(now-client.window>=1000){client.window=now;client.count=0;}if(++client.count>160){socket.close(1008,'Too many messages');return;}
        const message=JSON.parse(bytes.toString());if(!message||typeof message!=='object'||Array.isArray(message))throw new RoomError('消息格式不正确。');
        if(!client.user){
          if(client.authenticating)return;if(message.type!=='auth'||!/^[a-f0-9]{64}$/.test(message.token||'')){socket.close(4001,'Sign in required');return;}
          client.authenticating=true;client.token=message.token;
          try{const user=await accountSession(new Request('http://arena.local/api/chat/auth/me',{headers:{Authorization:'Bearer '+client.token}}),data.DB);if(socket.readyState!==1)return;client.user={id:user.id,username:user.username};clearTimeout(timeout);rooms.send(client,{type:'welcome',user:client.user,protocol:1,reconnected:rooms.members.has(user.id),roster:combat.roster.map(n=>n.id)});rooms.reconnect(client);}
          catch{socket.close(4001,'Session expired');}finally{client.authenticating=false;}return;
        }
        if(message.type==='ping'){rooms.send(client,{type:'pong',sent:message.sent});return;}
        if(message.type==='control'){rooms.input(client,message);return;}
        const counter=operations.get(client.user.id)||{at:now,count:0};if(now-counter.at>=60000){counter.at=now;counter.count=0;}if(++counter.count>30)throw new RoomError('房间操作过于频繁，请稍后再试。');operations.set(client.user.id,counter);
        await validate(client);if(socket.readyState!==1)return;
        switch(message.type){
          case 'create':rooms.create(client,message.team);break;
          case 'join':rooms.join(client,message.code,message.team);break;
          case 'ready':rooms.ready(client,message.ready,message.team);break;
          case 'leave':rooms.leave(client);break;
          default:throw new RoomError('不支持此房间操作。');
        }
      }catch(error){if(error.status===401){socket.close(4001,'Session expired');return;}rooms.send(client,{type:'error',message:error instanceof RoomError?error.message:'服务暂时不可用，请重试。'});if(++client.errors>20)socket.close(1008,'Invalid messages');}
    });
  });
  const tick=setInterval(()=>{try{rooms.tick();}catch(error){console.error('Match update failed:',error.message);}},1000/60);tick.unref();
  const health=setInterval(()=>{
    for(const client of clients){if(!client.alive){client.socket.terminate();continue;}client.alive=false;client.socket.ping();if(client.user)validate(client).catch(()=>client.socket.close(4001,'Session expired'));}
    for(const [id,value]of operations)if(Date.now()-value.at>120000)operations.delete(id);
  },15000);health.unref();
  return {server,rooms,data,clients,listen(port=3000,host='127.0.0.1'){return new Promise(resolve=>server.listen(port,host,()=>resolve(server.address())));},async close(){if(stopped)return;stopped=true;clearInterval(tick);clearInterval(health);for(const c of clients)c.socket.terminate();await new Promise(resolve=>sockets.close(resolve));await new Promise(resolve=>server.close(resolve));data.close();}};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const major=Number(process.versions.node.split('.')[0]);if(major!==24)throw Error('请使用 Node.js 24 LTS。');
  const app=createArenaServer({dataDirectory:process.env.ARENA_DATA_DIR,publicOrigin:process.env.PUBLIC_ORIGIN||undefined,trustProxy:process.env.TRUST_PROXY==='1',maxRooms:Math.max(1,Math.min(100,Number(process.env.MAX_ROOMS)||20))});
  const address=await app.listen(Number(process.env.PORT)||3000,process.env.HOST||'127.0.0.1');console.log(`忍道联机服务已启动：http://${address.address==='0.0.0.0'?'127.0.0.1':address.address}:${address.port}`);console.log('同一网址提供游戏、账号、聊天和联机房间。公网部署请配置 HTTPS。');
  for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>app.close().then(()=>process.exit(0)));
}
